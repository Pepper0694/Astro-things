import numpy as np
import matplotlib.pyplot as plt
from astropy.io import fits
import os
import glob
import re
from astropy.io import ascii

#To find the linear fit for the different spectrometers

#Vis_Calibration

PATH1='\\Users\\Jonathan\\Documents\\ASTR499\\Lab4\\Vis_calibration\\'
os.chdir(PATH1)
filename='mercury4.fit'
hdulist=fits.open(filename)
scidata = hdulist[0].data
tot=np.zeros(scidata.shape[1])

for row in scidata:
    tot+=row
    
y=np.arange(1530)
y=y[::-1]

#This block makes a list of maxima
L=np.argsort(-tot)
i=0
bad_idx=[]
#To remove multiple maxima for the same peak. 10 is the critical number, since 5 didn't work
for i in range(len(L)-1):
    if abs(L[i]-L[i+1])<10:
        bad_idx.append(i+1)
L=np.delete(L,bad_idx)

#Get 3 highest peaks
peaks=y[L[:3]]
print(peaks)

theo_Vis=[5460, 5769,5790]
theo_Vis=theo_Vis[::-1]


plt.plot(y,tot)
plt.show()

#Find the linear fit
fit_Vis=np.polyfit(peaks,theo_Vis,1)
print(fit_Vis)

#IR-Calibration

PATH2='\\Users\\Jonathan\\Documents\\ASTR499\\Lab4\\IR_calibration\\'
os.chdir(PATH2)
filename='neon6.fit'
hdulist=fits.open(filename)
scidata = hdulist[0].data
tot=np.zeros(scidata.shape[1])



for row in scidata:
    tot+=row
y=np.arange(1530)
y=y[::-1]

L=np.argsort(-tot)

i=0
for i in range(len(L)-1):
    if abs(L[i]-L[i+1])<10:
        bad_idx.append(i+1)
L=np.delete(L,bad_idx)
peaks=y[L[:3]]
print(peaks)

theo_IR=[5852, 6402,6678]
theo_IR=theo_IR[::-1]

peaks=np.array(peaks)

fit_IR=np.polyfit(peaks,theo_IR,1)
print(fit_IR)

plt.plot(y,tot)
plt.show()




#Glob allowed me to loop through the directory I created for the data
PATH3='\\Users\\Jonathan\\Documents\\ASTR499\\Lab4\\spectra\\'
os.chdir(PATH3)
for filename in glob.iglob('*.fit'):


    hdulist=fits.open(filename)
    scidata = hdulist[0].data
    
    tot=np.zeros(scidata.shape[1])
    
    for row in scidata:
        tot+=row
        
    y=np.arange(1530)
    
    y=np.array(y)

    #A check to see if the spectrum is in the visible or IR. The dual purpose is to name the graphs with obj later.
    obj_name=os.path.splitext(filename)[0]
    obj=re.sub(r'\W+', '', obj_name)
    fit=[]
    
    if 'IR' in obj:
        fit=fit_IR
    #I specified else instead of elif since there were a couple of objects without Vis or IR in the filenames.
    else:
        fit=fit_Vis
    y=y*fit[0]+fit[1]
    
    #Code to find local maxima checking in 25 angstrom intervals
    x=25
    spacing=25

    peaks=[]
    count=[]
    i=0

    for i in range(int(len(tot)/spacing)-1):
   
       peaks.append(y[np.argmax(tot[x-spacing:x])+x])
       count.append(tot[np.argmax(tot[x-spacing:x])+x])
       i+=1
       x+=spacing
    

    #Sort by showing the peaks with the highest counts first.
    count=np.array(count)
    peaks=np.array(peaks)
    
    ind_sort=np.argsort(count)

    peaks=peaks[ind_sort]
    count=count[ind_sort]



    
    count=count[::-1]
    
    y=y[::-1]
    plt.plot(y, tot)
    
    plt.title('Spectrum of'+ ' '+ obj)
    plt.xlabel('Wavelength ($\AA$)')
    plt.ylabel('Total Count')

    #Creating an ascii file to read off the peaks easily
    fmt={'count': '%i', 'wavelength': '%0.2f'}
    output={'count': count, 'wavelength':peaks}
    ascii.write(output,PATH3+ obj_name +'_calibrated_ascii', names=['count','wavelength'], formats=fmt) 
    
    
    plt.savefig(PATH3+ obj_name  +'_calibrated_graph.png')
    plt.show()
